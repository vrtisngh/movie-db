# Create your views here.

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.urls import reverse
from .models import Review
from .forms import ReviewForm
from movies_core.models import Movie

@login_required
def add_review(request, movie_id):
    movie = get_object_or_404(Movie, pk=movie_id)
    
    # Check if user already reviewed this movie
    existing_review = Review.objects.filter(movie=movie, user=request.user).first()
    if existing_review:
        messages.warning(request, "You have already reviewed this movie. You can edit your review instead.")
        return redirect('edit_review', review_id=existing_review.id)
    
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.movie = movie
            review.user = request.user
            review.save()
            messages.success(request, "Your review has been submitted!")
            return redirect('movie_detail', pk=movie.id)
    else:
        form = ReviewForm()
    
    return render(request, 'reviews/review_form.html', {
        'form': form,
        'movie': movie,
        'action': 'Add'
    })

@login_required
def edit_review(request, review_id):
    review = get_object_or_404(Review, pk=review_id, user=request.user)
    
    if request.method == 'POST':
        form = ReviewForm(request.POST, instance=review)
        if form.is_valid():
            form.save()
            messages.success(request, "Your review has been updated!")
            return redirect('movie_detail', pk=review.movie.id)
    else:
        form = ReviewForm(instance=review)
    
    return render(request, 'reviews/review_form.html', {
        'form': form,
        'movie': review.movie,
        'action': 'Edit'
    })

@login_required
def delete_review(request, review_id):
    review = get_object_or_404(Review, pk=review_id, user=request.user)
    movie_id = review.movie.id
    
    if request.method == 'POST':
        review.delete()
        messages.success(request, "Your review has been deleted.")
        return redirect('movie_detail', pk=movie_id)
    
    return render(request, 'reviews/review_confirm_delete.html', {
        'review': review
    })

def user_reviews(request):
    if not request.user.is_authenticated:
        messages.warning(request, "You need to be logged in to view your reviews.")
        return redirect('login')
    
    reviews = Review.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'reviews/user_reviews.html', {
        'reviews': reviews
    })
