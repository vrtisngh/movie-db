from django import forms
from .models import Movie, Genre, Director, Actor
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class MovieForm(forms.ModelForm):
    class Meta:
        model = Movie
        fields = ['title', 'release_date', 'description', 'poster', 'genres', 'director', 'actors', 'duration']
        widgets = {
            'release_date': forms.DateInput(attrs={'type': 'date'}),
            'description': forms.Textarea(attrs={'rows': 4}),
        }

class MovieSearchForm(forms.Form):
    query = forms.CharField(required=False, label='', 
    widget=forms.TextInput(attrs={'placeholder': 'Search movies...', 'class': 'form-control'}))
    genre = forms.ModelChoiceField(required=False, queryset=Genre.objects.all(), 
    empty_label="All Genres", label='Genre')
    sort_by = forms.ChoiceField(required=False, choices=[
        ('title', 'Title (A-Z)'),
        ('-title', 'Title (Z-A)'),
        ('release_date', 'Release Date (Oldest)'),
        ('-release_date', 'Release Date (Newest)'),
    ], label='Sort by')

class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(required=False)
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
