from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.urls import reverse_lazy
from django.db.models import Q
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from .models import Movie, Genre, Director, Actor
from .forms import MovieForm, MovieSearchForm, UserRegisterForm

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}! You can now log in.')
            return redirect('login')
    else:
        form = UserRegisterForm()
    return render(request, 'registration/register.html', {'form': form})

class MovieListView(ListView):
    model = Movie
    template_name = 'movies_core/movie_list.html'
    context_object_name = 'movies'
    paginate_by = 8
    
    def get_queryset(self):
        queryset = super().get_queryset()
        form = MovieSearchForm(self.request.GET)
        
        if form.is_valid():
            query = form.cleaned_data.get('query')
            genre = form.cleaned_data.get('genre')
            sort_by = form.cleaned_data.get('sort_by')
            
            if query:
                queryset = queryset.filter(
                    Q(title__icontains=query) | 
                    Q(description__icontains=query)
                )
            
            if genre:
                queryset = queryset.filter(genres=genre)
            
            if sort_by:
                queryset = queryset.order_by(sort_by)
            else:
                queryset = queryset.order_by('-release_date')
                
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_form'] = MovieSearchForm(self.request.GET)
        return context

class MovieDetailView(DetailView):
    model = Movie
    template_name = 'movies_core/movie_detail.html'
    context_object_name = 'movie'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Get reviews from the reviews app
        from reviews.models import Review
        context['reviews'] = Review.objects.filter(movie=self.object).order_by('-created_at')
        if self.request.user.is_authenticated:
            context['user_has_reviewed'] = Review.objects.filter(movie=self.object, user=self.request.user).exists()
        return context

class StaffRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return self.request.user.is_staff

class MovieCreateView(LoginRequiredMixin, StaffRequiredMixin, CreateView):
    model = Movie
    form_class = MovieForm
    template_name = 'movies_core/movie_form.html'
    success_url = reverse_lazy('movie_list')
    
    def form_valid(self, form):
        messages.success(self.request, "Movie created successfully!")
        return super().form_valid(form)

class MovieUpdateView(LoginRequiredMixin, StaffRequiredMixin, UpdateView):
    model = Movie
    form_class = MovieForm
    template_name = 'movies_core/movie_form.html'
    
    def form_valid(self, form):
        messages.success(self.request, "Movie updated successfully!")
        return super().form_valid(form)

class MovieDeleteView(LoginRequiredMixin, StaffRequiredMixin, DeleteView):
    model = Movie
    template_name = 'movies_core/movie_confirm_delete.html'
    success_url = reverse_lazy('movie_list')
    
    def delete(self, request, *args, **kwargs):
        messages.success(request, "Movie deleted successfully!")
        return super().delete(request, *args, **kwargs)

def home_view(request):
    recent_movies = Movie.objects.order_by('-release_date')[:4]
    top_rated_movies = sorted(Movie.objects.all(), key=lambda m: m.average_rating(), reverse=True)[:4]
    
    return render(request, 'movies_core/home.html', {
        'recent_movies': recent_movies,
        'top_rated_movies': top_rated_movies,
    })
