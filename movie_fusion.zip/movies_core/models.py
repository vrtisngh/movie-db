from django.db import models
from django.urls import reverse
from django.core.validators import MinValueValidator, MaxValueValidator

class Genre(models.Model):
    name = models.CharField(max_length=100, unique=True)
    
    def __str__(self):
        return self.name

class Director(models.Model):
    name = models.CharField(max_length=200)
    bio = models.TextField(blank=True)
    
    def __str__(self):
        return self.name

class Actor(models.Model):
    name = models.CharField(max_length=200)
    bio = models.TextField(blank=True)
    
    def __str__(self):
        return self.name

class Movie(models.Model):
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    description = models.TextField()
    poster = models.ImageField(upload_to='movie_posters/', blank=True, null=True,max_length=200)
    genres = models.ManyToManyField(Genre, related_name='movies')
    director = models.ForeignKey(Director, on_delete=models.SET_NULL, null=True, related_name='movies')
    actors = models.ManyToManyField(Actor, related_name='movies')
    duration = models.IntegerField(help_text="Duration in minutes")
    
    def __str__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse('movie_detail', kwargs={'pk': self.pk})
        
    def average_rating(self):
        from reviews.models import Review
        reviews = Review.objects.filter(movie=self)
        if reviews.count() > 0:
            return sum(review.rating for review in reviews) / reviews.count()
        return 0
